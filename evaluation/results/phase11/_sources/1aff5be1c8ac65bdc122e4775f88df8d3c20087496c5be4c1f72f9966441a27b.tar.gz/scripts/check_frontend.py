"""Run browser checks with only the local read token; never print credentials."""

import os
import subprocess
import sys
from pathlib import Path

from dotenv import dotenv_values

root = Path(__file__).resolve().parents[1]
env = os.environ.copy()
# IDE installed via Snap can inject incompatible glib/pthread modules into WebKit.
# Change only the child test process, leaving the shell and system untouched.
for name in (
    "GIO_EXTRA_MODULES",
    "GIO_MODULE_DIR",
    "GTK_PATH",
    "GTK_EXE_PREFIX",
    "GDK_PIXBUF_MODULEDIR",
    "GDK_PIXBUF_MODULE_FILE",
    "GSETTINGS_SCHEMA_DIR",
    "GI_TYPELIB_PATH",
    "LIBGL_DRIVERS_PATH",
    "__EGL_VENDOR_LIBRARY_DIRS",
    "LD_PRELOAD",
):
    if "/snap/" in env.get(name, ""):
        env.pop(name)
env["PATH"] = str(root / ".tools/node/bin") + os.pathsep + env["PATH"]
env["PLAYWRIGHT_BROWSERS_PATH"] = str(root / ".cache/playwright")
env["LD_LIBRARY_PATH"] = (
    str(root / ".cache/browser-libs/root/usr/lib/x86_64-linux-gnu")
    + os.pathsep
    + os.pathsep.join(
        part for part in env.get("LD_LIBRARY_PATH", "").split(os.pathsep) if "/snap/" not in part
    )
)
env["API_TOKEN"] = dotenv_values(root / ".env").get("API_TOKEN") or ""
result = subprocess.run(
    ["npm", "exec", "playwright", "--", "test", *sys.argv[1:]],
    cwd=root / "frontend",
    env=env,
    check=False,
)
raise SystemExit(result.returncode)
