"""Public response schemas."""
