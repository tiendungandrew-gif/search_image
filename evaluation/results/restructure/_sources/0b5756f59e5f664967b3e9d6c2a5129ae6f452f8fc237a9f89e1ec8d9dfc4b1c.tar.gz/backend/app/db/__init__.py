"""SQLAlchemy session và metadata."""
