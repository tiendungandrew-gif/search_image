import { useEffect, useRef, useState } from "react";
import { api } from "../../services/api/client";
import type { ImageDetail } from "../../types/api";
import { ConstraintEvidence, type GalleryImage } from "./ResultGallery";
import { ResultImage } from "./ResultImage";

export default function ImageDetailDialog({
  images,
  selected,
  token,
  onSelect,
  onClose,
}: {
  images: GalleryImage[];
  selected: number;
  token: string;
  onSelect: (index: number) => void;
  onClose: () => void;
}) {
  const dialog = useRef<HTMLDialogElement>(null);
  const [detail, setDetail] = useState<ImageDetail | null>(null);
  const [error, setError] = useState<{ id: string; message: string } | null>(
    null,
  );
  const [attempt, setAttempt] = useState(0);
  const image = images[selected];
  const previous = () =>
    onSelect((selected - 1 + images.length) % images.length);
  const next = () => onSelect((selected + 1) % images.length);
  useEffect(() => {
    const opener = document.activeElement as HTMLElement | null;
    const element = dialog.current;
    element?.showModal();
    return () => {
      element?.close();
      opener?.focus();
    };
  }, []);
  useEffect(() => {
    const request = new AbortController();
    void api
      .imageDetail(image.image_id, token, request.signal)
      .then((value) => {
        if (!request.signal.aborted) setDetail(value);
      })
      .catch((issue) => {
        if (!request.signal.aborted)
          setError({
            id: image.image_id,
            message:
              issue instanceof Error
                ? issue.message
                : "Không tải được metadata.",
          });
      });
    return () => request.abort();
  }, [image.image_id, token, attempt]);
  const currentError = error?.id === image.image_id ? error.message : null;
  const current = detail?.image_id === image.image_id ? detail : null;
  const meta = current?.metadata ?? image.metadata;
  return (
    <dialog
      className="image-dialog"
      ref={dialog}
      aria-labelledby="detail-title"
      aria-describedby="detail-position"
      onCancel={(event) => {
        event.preventDefault();
        onClose();
      }}
      onKeyDown={(event) => {
        if (event.key === "ArrowLeft") {
          event.preventDefault();
          previous();
        }
        if (event.key === "ArrowRight") {
          event.preventDefault();
          next();
        }
      }}
    >
      <div className="dialog-toolbar">
        <p id="detail-position" role="status">
          Ảnh {selected + 1} / {images.length} · Hạng {image.rank}
        </p>
        <div>
          <button type="button" onClick={previous} aria-label="Ảnh trước">
            ←
          </button>
          <button type="button" onClick={next} aria-label="Ảnh tiếp theo">
            →
          </button>
          <button
            type="button"
            autoFocus
            onClick={onClose}
            aria-label="Đóng chi tiết ảnh"
          >
            Đóng ✕
          </button>
        </div>
      </div>
      <div className="dialog-body">
        <div className="detail-image">
          <ResultImage
            key={image.image_id}
            eager
            url={image.image_url}
            token={token}
            alt={meta.title ?? "Ảnh gốc"}
          />
        </div>
        <section className="detail-metadata">
          <h2 id="detail-title">{meta.title || "Chi tiết ảnh"}</h2>
          {!current && !currentError && <p role="status">Đang tải metadata…</p>}
          {currentError && (
            <div role="alert">
              <p>{currentError}</p>
              <button
                type="button"
                onClick={() => {
                  setError(null);
                  setAttempt((n) => n + 1);
                }}
              >
                Thử lại metadata
              </button>
              <p>Thông tin bên dưới lấy từ kết quả tìm kiếm.</p>
            </div>
          )}
          <p>{meta.caption || "Chưa có chú thích"}</p>
          <dl>
            {Object.entries({
              "Mã ảnh": image.image_id,
              "Kích thước": `${meta.width} × ${meta.height}`,
              "Định dạng": meta.media_type,
              Dataset: meta.source_dataset,
              "Thành phố": meta.city,
              "Giấy phép": meta.license,
              "Điểm xếp hạng":
                image.score === null
                  ? null
                  : `${image.score_type} ${image.score.toFixed(5)}`,
              "Ngày tạo": current?.created_at,
            }).map(([label, value]) => (
              <div key={label}>
                <dt>{label}</dt>
                <dd>{value || "Chưa có thông tin"}</dd>
              </div>
            ))}
          </dl>
          <div className="tag-list">
            {meta.tags.map((tag) => (
              <span key={tag}>{tag}</span>
            ))}
          </div>
          <ConstraintEvidence
            assessments={image.constraint_assessments ?? []}
          />
          <p className="muted">
            Ảnh được tải qua API có xác thực. Điểm truy xuất không xác nhận sự
            hiện diện của đối tượng trong ảnh.
          </p>
        </section>
      </div>
    </dialog>
  );
}
