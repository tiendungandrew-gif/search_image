import { lazy, Suspense, useLayoutEffect, useState } from "react";
import type { ImageMetadata, SearchResult } from "../../types/api";
import { ResultImage } from "./ResultImage";

const ImageDetailDialog = lazy(() => import("./ImageDetailDialog"));
export interface GalleryImage {
  image_id: string;
  rank: number;
  score: number | null;
  score_type: string | null;
  image_url: string;
  thumbnail_url: string;
  metadata: ImageMetadata;
  constraint_assessments?: SearchResult["constraint_assessments"];
}
export function ConstraintEvidence({
  assessments,
}: {
  assessments: NonNullable<GalleryImage["constraint_assessments"]>;
}) {
  return (
    assessments.length > 0 && (
      <ul className="constraint-evidence">
        {assessments.map((item) => (
          <li key={item.clause_id}>
            {item.clause_id}:{" "}
            {item.status === "satisfied"
              ? "Metadata khớp"
              : item.status === "violated"
                ? "Metadata không khớp"
                : "Chưa xác minh"}
            {item.semantic_score != null
              ? ` · cosine ${item.semantic_score.toFixed(3)}`
              : ""}
            {item.evidence_ref && (
              <small>Bằng chứng: {item.evidence_ref}</small>
            )}
          </li>
        ))}
      </ul>
    )
  );
}
export function ResultGallery({
  images,
  token,
  onVisible,
}: {
  images: GalleryImage[];
  token: string;
  onVisible?: () => void;
}) {
  const [selected, setSelected] = useState<number | null>(null);
  useLayoutEffect(() => {
    let second = 0;
    const first = requestAnimationFrame(() => {
      second = requestAnimationFrame(() => onVisible?.());
    });
    return () => {
      cancelAnimationFrame(first);
      cancelAnimationFrame(second);
    };
  }, [onVisible]);
  return (
    <>
      <p className="gallery-note">
        Theo thứ hạng từ backend · Điểm xếp hạng không phải xác suất.
      </p>
      <div className="result-grid">
        {images.map((image, index) => (
          <article
            className="result-card"
            key={image.image_id}
            id={`image-${image.image_id}`}
            tabIndex={-1}
          >
            <div className="card-image-wrap">
              <ResultImage
                url={image.thumbnail_url}
                token={token}
                alt={
                  image.metadata.title ?? `Ảnh ${image.image_id.slice(0, 8)}`
                }
              />
              <span className="rank-badge">#{image.rank}</span>
            </div>
            <div className="result-description">
              <h3>
                <button
                  type="button"
                  className="detail-trigger"
                  onClick={() => setSelected(index)}
                  aria-label={`Xem chi tiết ảnh hạng ${image.rank}`}
                >
                  {image.metadata.title ?? `Ảnh ${image.image_id.slice(0, 8)}`}{" "}
                  <span aria-hidden="true">↗</span>
                </button>
              </h3>
              <p>{image.metadata.caption || "Chưa có chú thích"}</p>
              <div className="card-metrics">
                <span>
                  {image.score === null
                    ? "Không có điểm ngữ nghĩa"
                    : `${image.score_type ?? "Điểm"} ${image.score.toFixed(image.score_type === "rrf" ? 5 : 3)}`}
                </span>
                <small>
                  {image.metadata.width} × {image.metadata.height}
                </small>
              </div>
              <small>
                {image.metadata.source_dataset || "Chưa có nguồn dataset"}
              </small>
              {image.metadata.tags.length > 0 && (
                <div className="tag-list">
                  {image.metadata.tags.map((tag) => (
                    <span key={tag}>{tag}</span>
                  ))}
                </div>
              )}
              <ConstraintEvidence
                assessments={image.constraint_assessments ?? []}
              />
            </div>
          </article>
        ))}
      </div>
      {selected !== null && (
        <Suspense fallback={<p role="status">Đang mở chi tiết ảnh…</p>}>
          <ImageDetailDialog
            images={images}
            selected={selected}
            token={token}
            onSelect={setSelected}
            onClose={() => setSelected(null)}
          />
        </Suspense>
      )}
    </>
  );
}
