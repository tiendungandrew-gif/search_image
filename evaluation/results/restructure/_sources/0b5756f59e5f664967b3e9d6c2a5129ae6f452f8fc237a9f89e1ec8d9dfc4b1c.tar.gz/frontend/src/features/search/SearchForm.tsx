import { useState } from "react";
import { Icon } from "../../components/Icon";
import { APIClientError } from "../../services/api/client";
import type {
  HealthSummary,
  SearchMode,
  WorkspaceStatus,
} from "../../types/api";
import { AdvancedControls } from "./AdvancedControls";
import { defaultAdvanced, filterError, validateImage } from "./validation";
import { ImageUpload } from "./ImageUpload";
import type { useSearchSession } from "./useSearchSession";
const modeLabels: Record<SearchMode, string> = {
  auto: "Tự động theo đầu vào",
  text: "Văn bản → Hình ảnh",
  image: "Hình ảnh → Hình ảnh",
  multimodal: "Văn bản + Hình ảnh",
  multi_intent: "Nhiều điều kiện · AND / OR",
  agent: "Agent · Tra cứu nhiều bước",
};
export function SearchForm({
  token,
  onTokenChange,
  available = false,
  agentAvailable = false,
  capabilities,
  workspace,
  mode,
  onModeChange,
  session,
}: {
  token: string;
  onTokenChange: (value: string) => void;
  available?: boolean;
  agentAvailable?: boolean;
  capabilities?: HealthSummary["capabilities"];
  workspace?: WorkspaceStatus | null;
  mode: SearchMode;
  onModeChange: (mode: SearchMode) => void;
  session: ReturnType<typeof useSearchSession>;
}) {
  const [query, setQuery] = useState("");
  const [topK, setTopK] = useState(10);
  const [file, setFile] = useState<File | null>(null);
  const [advanced, setAdvanced] = useState(defaultAdvanced);
  const [includeExplanation, setIncludeExplanation] = useState(false);
  const [planner, setPlanner] = useState("deterministic");
  const loading = session.state === "SEARCHING";
  const caps = workspace?.capabilities ?? capabilities;
  const supported: Record<SearchMode, boolean> = {
    auto: caps ? caps.text_search || caps.image_search : available,
    text: caps?.text_search ?? available,
    image: caps?.image_search ?? available,
    multimodal: caps?.multimodal ?? available,
    multi_intent: caps?.multi_intent ?? available,
    agent: caps?.agent ?? agentAvailable,
  };
  const ragAvailable = caps?.explanations ?? false;
  const rerankAvailable = caps?.rerank ?? available;
  const maxK = workspace?.limits.top_k ?? 50;
  const maxBytes = workspace?.limits.image_bytes ?? 20 * 1024 ** 2;
  const imageMode = ["image", "multimodal", "auto"].includes(mode);
  const usesImage = imageMode && file !== null;
  const combined = usesImage && mode !== "image" && query.trim().length > 0;
  const inputsReady =
    mode === "multimodal"
      ? file && query.trim()
      : mode === "image"
        ? file
        : mode === "auto"
          ? file || query.trim()
          : query.trim();
  async function submit() {
    if (!token.trim())
      return session.validationError("Nhập token truy cập trước khi tìm kiếm.");
    if (!supported[mode])
      return session.validationError(
        "Phương thức này chưa sẵn sàng. Kiểm tra trạng thái dataset.",
      );
    if (!inputsReady)
      return session.validationError(
        "Bổ sung văn bản hoặc ảnh theo phương thức đã chọn.",
      );
    if (
      query.trim().length > 2000 ||
      topK < 1 ||
      topK > maxK ||
      !Number.isInteger(topK)
    )
      return session.validationError(
        `Truy vấn tối đa 2000 ký tự; số kết quả từ 1 đến ${maxK}.`,
      );
    const issue = mode === "agent" ? null : filterError(advanced.filters);
    if (issue) return session.validationError(issue);
    if (usesImage && file) {
      const issue = validateImage(file, maxBytes);
      if (issue) return session.validationError(issue);
    }
    if (
      mode === "auto" &&
      ((combined && !supported.multimodal) ||
        (usesImage && !supported.image) ||
        (!usesImage && !supported.text))
    )
      return session.validationError(
        "Backend chưa hỗ trợ loại đầu vào này. Chọn phương thức đang khả dụng.",
      );
    await session.execute(
      {
        mode,
        ...(mode !== "image" && query.trim() ? { text: query.trim() } : {}),
        top_k: topK,
        rerank: {
          enabled: advanced.rerank && rerankAvailable,
          on_failure: "skip",
        },
        ...(mode !== "agent" ? { filters: advanced.filters } : {}),
        ...(combined
          ? {
              fusion: {
                method: advanced.fusion,
                text_weight: advanced.textWeight,
                image_weight: 1 - advanced.textWeight,
              },
            }
          : {}),
      },
      usesImage ? file : null,
      {
        includeExplanation: includeExplanation && ragAvailable,
        planner:
          planner === "llm" && workspace?.agent.llm_planning === false
            ? "deterministic"
            : planner,
      },
    );
  }
  return (
    <section className="search-card" aria-labelledby="search-heading">
      <div className="card-kicker">
        <span className="accent-dot" /> KHÔNG GIAN TÌM KIẾM{" "}
        <span className="soon-badge">
          {supported[mode] ? "Sẵn sàng khám phá" : "Đang chờ chỉ mục"}
        </span>
      </div>
      <h2 id="search-heading">Bắt đầu bằng một ý tưởng.</h2>
      <p className="muted">
        Mô tả điều bạn đang tìm hoặc chọn một ảnh làm điểm xuất phát.
      </p>
      <form
        onSubmit={(event) => {
          event.preventDefault();
          void submit();
        }}
      >
        <label className="field-label" htmlFor="search-token">
          Token truy cập
        </label>
        <input
          id="search-token"
          type="password"
          autoComplete="off"
          spellCheck={false}
          value={token}
          onChange={(event) => onTokenChange(event.target.value)}
        />
        <p className="field-hint">
          Token chỉ giữ trong phiên này, không lưu trên trình duyệt.
        </p>
        <label className="field-label" htmlFor="query">
          Bạn đang tìm hình ảnh nào?
        </label>
        <textarea
          id="query"
          value={query}
          disabled={mode === "image"}
          onChange={(event) => setQuery(event.target.value)}
          maxLength={2000}
          placeholder="Ví dụ: Một quán cà phê bên cửa sổ, trong ánh nắng sớm…"
          rows={3}
          aria-describedby="query-hint"
          onKeyDown={(event) => {
            if (
              event.key === "Enter" &&
              !event.shiftKey &&
              !event.nativeEvent.isComposing
            ) {
              event.preventDefault();
              if (!loading) event.currentTarget.form?.requestSubmit();
            }
          }}
        />
        <div id="query-hint" className="input-caption">
          <span>Enter để tìm · Shift + Enter để xuống dòng</span>
          <span>{query.length} / 2000</span>
        </div>
        <div className="form-row">
          <div className="mode-field">
            <label htmlFor="mode">Phương thức</label>
            <select
              id="mode"
              value={mode}
              onChange={(event) => {
                session.reset();
                onModeChange(event.target.value as SearchMode);
              }}
            >
              {Object.entries(modeLabels).map(([key, label]) => (
                <option
                  key={key}
                  value={key}
                  disabled={key !== "auto" && !supported[key as SearchMode]}
                >
                  {label}
                  {!supported[key as SearchMode] ? " · chưa sẵn sàng" : ""}
                </option>
              ))}
            </select>
          </div>
          <div className="top-k-field">
            <label htmlFor="top-k">Số kết quả</label>
            <input
              id="top-k"
              type="number"
              min={1}
              max={maxK}
              step={1}
              value={topK}
              onChange={(event) => setTopK(Number(event.target.value))}
            />
          </div>
          <button
            className="search-button"
            type="submit"
            disabled={
              !supported[mode] || !token.trim() || loading || !inputsReady
            }
            aria-describedby="search-unavailable"
          >
            <Icon kind="search" />
            {loading ? "Đang tìm kiếm…" : "Tìm kiếm ảnh"}
            <Icon kind="arrow" />
          </button>
        </div>
        {mode === "agent" && (
          <div className="advanced-controls">
            <label className="field-label" htmlFor="agent-planner">
              Lập kế hoạch
            </label>
            <select
              id="agent-planner"
              value={planner}
              onChange={(event) => setPlanner(event.target.value)}
            >
              <option value="deterministic">Theo mẫu đã hỗ trợ</option>
              <option
                value="llm"
                disabled={workspace?.agent.llm_planning === false}
              >
                LLM có kiểm tra kế hoạch
              </option>
            </select>
            <label className="rerank-control">
              <input
                type="checkbox"
                disabled={!ragAvailable}
                checked={includeExplanation && ragAvailable}
                onChange={(event) =>
                  setIncludeExplanation(event.target.checked)
                }
              />{" "}
              Giải thích sau khi tìm ảnh
            </label>
            <p className="muted">
              Agent tra cứu quan hệ có nguồn và chỉ hiển thị các bước công khai.
            </p>
          </div>
        )}
        {imageMode && (
          <ImageUpload file={file} onChange={setFile} maxBytes={maxBytes} />
        )}
        <AdvancedControls
          value={advanced}
          onChange={setAdvanced}
          fusionAvailable={combined && supported.multimodal}
          rerankAvailable={rerankAvailable}
          disabled={mode === "agent"}
        />
        <div className="search-actions">
          <button
            type="button"
            className="text-button"
            onClick={() => {
              session.reset();
              setQuery("");
              setFile(null);
            }}
          >
            Xóa truy vấn
          </button>
          {loading && (
            <button
              type="button"
              className="cancel-button"
              onClick={session.cancel}
            >
              {mode === "agent" ? "Dừng Agent" : "Hủy tìm kiếm"}
            </button>
          )}
        </div>
        {session.error && (
          <div role="alert" className="error-message">
            <p>{session.error.message}</p>
            {session.error instanceof APIClientError && (
              <small>
                Mã: {session.error.code}
                {session.error.requestId
                  ? ` · Request: ${session.error.requestId}`
                  : ""}
              </small>
            )}
            <p>
              Kiểm tra đầu vào, kết nối hoặc quyền truy cập rồi gửi lại khi sẵn
              sàng.
            </p>
          </div>
        )}
      </form>
      <p id="search-unavailable" className="availability-note">
        <span className="note-symbol">i</span>
        {supported[mode]
          ? "Tìm bằng văn bản, ảnh hoặc kết hợp. Điểm xếp hạng không phải xác suất; điều kiện chưa xác minh sẽ được ghi rõ."
          : "Tìm kiếm chưa sẵn sàng. Kiểm tra model và active index."}
      </p>
    </section>
  );
}
