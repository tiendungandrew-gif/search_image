import { lazy, Suspense, useState, useEffect, Profiler } from "react";
import { Icon } from "../../components/Icon";
import type {
  HealthSummary,
  SearchMode,
  WorkspaceStatus,
} from "../../types/api";
import { SearchForm } from "./SearchForm";
import { QueryAnalysis } from "./QueryAnalysis";
import { ResultGallery } from "./ResultGallery";
import { SearchSkeleton } from "./SearchSkeleton";
import { useSearchSession } from "./useSearchSession";
const ExplanationPanel = lazy(() =>
  import("../rag/ExplanationPanel").then((module) => ({
    default: module.ExplanationPanel,
  })),
);
const AgentResults = lazy(() =>
  import("../agent/AgentResults").then((module) => ({
    default: module.AgentResults,
  })),
);

export function SearchWorkspace({
  token,
  onTokenChange,
  available = false,
  agentAvailable = false,
  capabilities,
  workspace,
}: {
  token: string;
  onTokenChange: (value: string) => void;
  available?: boolean;
  agentAvailable?: boolean;
  capabilities?: HealthSummary["capabilities"];
  workspace?: WorkspaceStatus | null;
}) {
  const [mode, setMode] = useState<SearchMode>("auto");
  const session = useSearchSession(token);
  const loading = session.state === "SEARCHING";
  const ragAvailable =
    (workspace?.capabilities ?? capabilities)?.explanations ?? false;
  const result = session.results;
  useEffect(() => {
    if (!result) return;
    const frame = requestAnimationFrame(() =>
      document.getElementById("results-heading")?.focus(),
    );
    return () => cancelAnimationFrame(frame);
  }, [result]);
  return (
    <>
      <SearchForm
        token={token}
        onTokenChange={onTokenChange}
        available={available}
        agentAvailable={agentAvailable}
        capabilities={capabilities}
        workspace={workspace}
        mode={mode}
        onModeChange={setMode}
        session={session}
      />
      <div className="session-status" role="status" aria-live="polite">
        {session.state === "CANCELLED"
          ? "Đã hủy yêu cầu. Bạn có thể tiếp tục tìm kiếm."
          : loading
            ? "Đang tìm kiếm…"
            : result
              ? `Đã nhận ${result.total_results} kết quả.`
              : ""}
      </div>
      {mode === "agent" ? (
        <Suspense fallback={<p role="status">Đang mở Agent…</p>}>
          <AgentResults
            response={session.agent}
            progress={session.progress}
            loading={loading}
            token={token}
          />
        </Suspense>
      ) : (
        <section
          className="results-section"
          aria-labelledby="results-heading"
          data-state={session.state}
          data-search-started={session.metrics.started}
          data-api-ms={session.metrics.apiMs?.toFixed(2)}
          data-first-result-ms={session.metrics.visibleMs?.toFixed(2)}
          data-render-ms={session.metrics.renderMs?.toFixed(2)}
          data-react-ms={session.metrics.reactMs?.toFixed(2)}
        >
          <div className="section-title">
            <h2 id="results-heading" tabIndex={-1}>
              Kết quả tìm kiếm
            </h2>
            <span>
              {result
                ? `${result.total_results} kết quả · ${result.latency.processing_ms.toFixed(1)} ms xử lý`
                : "Chưa có kết quả"}
            </span>
          </div>
          {loading ? (
            <SearchSkeleton />
          ) : result && result.results.length > 0 ? (
            <>
              <QueryAnalysis response={result} />
              <Profiler id="results" onRender={session.markReact}>
                <ResultGallery
                  key={result.query_id}
                  images={result.results}
                  token={token}
                  onVisible={session.markVisible}
                />
              </Profiler>
              {ragAvailable ? (
                <Suspense fallback={<p role="status">Đang mở giải thích…</p>}>
                  <ExplanationPanel
                    key={result.query_id}
                    results={result}
                    token={token}
                    query={session.submittedQuery}
                    streaming={workspace?.rag.streaming ?? false}
                  />
                </Suspense>
              ) : (
                <p className="availability-note">
                  Giải thích AI chưa khả dụng. Bạn vẫn có thể xem ảnh và
                  metadata.
                </p>
              )}
            </>
          ) : (
            <div className="empty-results" role="status">
              <span className="empty-icon">
                <Icon kind="layers" />
              </span>
              <h3>
                {workspace?.dataset.state === "empty_dataset"
                  ? "Chưa có dữ liệu ảnh."
                  : session.state === "ERROR" ||
                      session.state === "INDEX_NOT_READY"
                    ? "Chưa nhận được kết quả."
                    : result
                      ? "Không tìm thấy ảnh phù hợp."
                      : "Một không gian cho những điều bạn tìm."}
              </h3>
              <p>
                {workspace?.dataset.state === "empty_dataset"
                  ? "Nhập dataset theo hướng dẫn vận hành, sau đó làm mới trạng thái. Giao diện sẽ tự nhận dữ liệu mới."
                  : result
                    ? "Dataset đang có dữ liệu. Thử nới bộ lọc hoặc đổi mô tả."
                    : "Nhập token và bắt đầu bằng lời mô tả hoặc ảnh tham chiếu."}
              </p>
            </div>
          )}
          {result?.warnings.map((warning, i) => (
            <p className="availability-note" key={`${warning.code}-${i}`}>
              {warning.message}
            </p>
          ))}
          {session.metrics.visibleMs !== null && (
            <p className="performance-note">
              API {session.metrics.apiMs?.toFixed(0)} ms · Hiển thị thẻ kết quả{" "}
              {session.metrics.visibleMs.toFixed(0)} ms từ lúc gửi · Ảnh tải
              theo vùng nhìn thấy.
            </p>
          )}
        </section>
      )}
    </>
  );
}
