"""Worker thường trực: idle khi chưa có dataset, lazy-load model, heartbeat an toàn."""

import argparse
import asyncio
import json
import os
import signal
import time
from pathlib import Path

HEARTBEAT = Path("/run/app/worker.json")


def health(path=HEARTBEAT):
    value = json.loads(path.read_text())
    fresh = time.time() - value["heartbeat_unix"] < 30
    return fresh and value["state"] in {"idle", "running", "stopping"}


async def serve():
    from sqlalchemy import select

    from app.core.config import Settings
    from app.core.logging import configure_logging
    from app.db.models import SearchIndex
    from app.db.models.indexing import JobItem
    from app.services.embeddings.clip_encoder import ClipEncoder
    from app.services.health import Services
    from app.services.indexing.worker import Worker

    settings = Settings()
    configure_logging(settings.log_level)
    services = Services(settings)
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for name in [signal.SIGTERM, signal.SIGINT]:
        loop.add_signal_handler(name, stop.set)
    state = {"state": "idle", "pid": os.getpid(), "index_id": None, "error_category": None}

    async def heartbeat():
        HEARTBEAT.parent.mkdir(parents=True, exist_ok=True)
        while not stop.is_set():
            temporary = HEARTBEAT.with_suffix(".tmp")
            temporary.write_text(json.dumps({**state, "heartbeat_unix": time.time()}))
            temporary.replace(HEARTBEAT)
            try:
                await asyncio.wait_for(stop.wait(), timeout=5)
            except TimeoutError:
                pass

    monitor = asyncio.create_task(heartbeat())
    encoder = None
    try:
        while not stop.is_set():
            try:
                async with services.database.sessions() as session:
                    identity = await session.scalar(
                        select(JobItem.index_id)
                        .join(SearchIndex, SearchIndex.id == JobItem.index_id)
                        .where(
                            SearchIndex.status.in_(["building", "ready"]),
                            JobItem.status.in_(
                                ["awaiting_input", "queued", "retry_wait", "processing"]
                            ),
                        )
                        .order_by(JobItem.created_at)
                        .limit(1)
                    )
                if identity is not None:
                    state.update(state="running", index_id=str(identity), error_category=None)
                    if encoder is None:
                        encoder = await asyncio.to_thread(ClipEncoder, settings)
                    await Worker(services, encoder, identity).run(once=True)
                state.update(state="idle", index_id=None, error_category=None)
                delay = 2
            except Exception as error:
                state.update(
                    state="blocked",
                    error_category="MODEL_NOT_INSTALLED"
                    if isinstance(error, (FileNotFoundError, ImportError))
                    else "WORKER_OPERATION_FAILED",
                )
                delay = 15
            try:
                await asyncio.wait_for(stop.wait(), timeout=delay)
            except TimeoutError:
                pass
    finally:
        stop.set()
        state["state"] = "stopping"
        await monitor
        await services.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--health", action="store_true")
    args = parser.parse_args()
    if args.health:
        try:
            raise SystemExit(0 if health() else 1)
        except (OSError, ValueError, KeyError):
            raise SystemExit(1) from None
    asyncio.run(serve())


if __name__ == "__main__":
    main()
