import pytest

from app.evaluation.agent import evaluate_labeled_cases


def test_fixture_metric_denominators_and_scope_do_not_become_real_accuracy():
    rows = [
        {
            "case_id": "unit",
            "result": {
                "search_mode": "agent",
                "steps": [{"tool": "entity_lookup"}],
                "resolved_entities": [],
                "evidence": [],
                "results": [],
                "status": "insufficient_evidence",
            },
        }
    ]
    labels = {
        "fixture": True,
        "cases": {
            "unit": {
                "search_mode": "agent",
                "tools": ["entity_lookup"],
                "entity_ids": [],
                "relationship_ids": [],
                "image_ids": [],
                "status": "insufficient_evidence",
            }
        },
    }
    scored = evaluate_labeled_cases(rows, labels)
    assert scored["classification"] == "synthetic_fixture"
    assert scored["metrics"]["workflow_success"] == 1
    assert scored["real_world_retrieval_accuracy"] is None
    labels["fixture"] = False
    with pytest.raises(ValueError, match="VERIFIED_AGENT_LABELS_REQUIRED"):
        evaluate_labeled_cases(rows, labels)


def test_fixture_coverage_is_required_and_zero_denominator_stays_unknown():
    result = evaluate_labeled_cases([], {"fixture": True, "cases": {}})
    assert all(v is None for v in result["metrics"].values())
    with pytest.raises(ValueError, match="COVERAGE"):
        evaluate_labeled_cases([], {"fixture": True, "cases": {"missing": {}}})
