import { render, screen } from "@testing-library/react";
import { AgentResults } from "./AgentResults";

test("empty dataset displays no fabricated cards or steps", () => {
  render(
    <AgentResults
      loading={false}
      token="unit"
      progress={[]}
      response={{
        query_id: "unit",
        status: "insufficient_evidence",
        query_success: false,
        dataset_status: "empty_dataset",
        results: [],
        steps: [],
        latency_ms: 1,
        logical_hops: 0,
        tool_calls: 0,
        warnings: ["EMPTY_DATASET"],
        error_code: "EMPTY_DATASET",
        relationship_summary: null,
        rag: null,
      }}
    />,
  );
  expect(screen.getByText(/Chưa có dữ liệu ảnh/)).toBeInTheDocument();
  expect(screen.queryByRole("img")).not.toBeInTheDocument();
  expect(
    screen.queryByLabelText("Các bước đã thực hiện"),
  ).not.toBeInTheDocument();
});
