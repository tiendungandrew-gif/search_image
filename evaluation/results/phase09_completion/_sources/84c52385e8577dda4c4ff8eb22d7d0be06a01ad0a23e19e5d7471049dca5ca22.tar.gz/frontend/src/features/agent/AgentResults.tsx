import { ResultImage } from "../search/ResultImage";
import type { AgentResponse } from "./api";

import { toolLabels } from "./tools";

function publicSource(value: string) {
  try {
    const url = new URL(value);
    return url.protocol === "https:" && !url.username && !url.password
      ? url.href
      : null;
  } catch {
    return null;
  }
}
export function AgentResults({
  response,
  progress,
  loading,
  token,
}: {
  response: AgentResponse | null;
  progress: string[];
  loading: boolean;
  token: string;
}) {
  return (
    <section
      className="results-section"
      aria-labelledby="agent-results-heading"
      data-testid="agent-results"
    >
      <h2 id="agent-results-heading">Kết quả Agent Search</h2>
      {loading && <p role="status">Đang xử lý truy vấn…</p>}
      <ol className="agent-progress" aria-label="Tiến độ Agent">
        {progress.map((message, i) => (
          <li key={i}>{message}</li>
        ))}
      </ol>
      {response && (
        <>
          <p className="availability-note" data-testid="agent-status">
            {response.status === "completed"
              ? "Đã hoàn tất truy xuất"
              : response.status === "partial"
                ? "Kết quả một phần"
                : response.status === "timeout"
                  ? "Đã hết thời gian xử lý"
                  : "Chưa đủ bằng chứng để trả lời"}
            {` · ${response.latency_ms.toFixed(1)} ms`}
          </p>
          {response.dataset_status === "empty_dataset" && (
            <p>
              Chưa có dữ liệu ảnh để tìm kiếm. Bạn vẫn có thể sử dụng các chức
              năng khác.
            </p>
          )}
          {!response.results.length &&
            response.dataset_status !== "empty_dataset" && (
              <p>
                Chưa tìm được ảnh có đủ bằng chứng cho truy vấn này. Quan hệ
                chưa được xác nhận sẽ không được dùng để suy đoán kết quả.
              </p>
            )}
          {response.steps.length > 0 && (
            <ol aria-label="Các bước đã thực hiện">
              {response.steps.map((step) => (
                <li key={step.step_id}>
                  {toolLabels[step.tool] ?? step.tool} · {step.status} ·{" "}
                  {step.duration_ms.toFixed(1)} ms
                </li>
              ))}
            </ol>
          )}
          {response.relationship_summary && (
            <p>
              Quan hệ có nguồn trong dữ liệu: {response.relationship_summary}
            </p>
          )}
          {response.evidence?.some((e) => e.verified) && (
            <details>
              <summary>Nguồn quan hệ</summary>
              <ul>
                {[
                  ...new Set(
                    response.evidence
                      .filter((e) => e.verified)
                      .map((e) => e.source_ref),
                  ),
                ].map((source) => {
                  const href = publicSource(source);
                  return (
                    <li key={source}>
                      {href ? (
                        <a
                          href={href}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          {source}
                        </a>
                      ) : (
                        <span>{source}</span>
                      )}
                    </li>
                  );
                })}
              </ul>
            </details>
          )}
          {response.rag && (
            <div className="explanation-panel">
              <h3>Giải thích</h3>
              <p style={{ whiteSpace: "pre-wrap" }}>{response.rag.answer}</p>
              <ul>
                {response.rag.citations.map((c, i) => (
                  <li key={i}>
                    <a href={`#image-${c.image_id}`}>
                      Ảnh {c.image_id.slice(0, 8)}
                    </a>{" "}
                    · {c.quote}
                  </li>
                ))}
              </ul>
            </div>
          )}
          <div className="result-grid">
            {response.results.map((image) => (
              <article
                className="result-card"
                key={image.image_id}
                id={`image-${image.image_id}`}
              >
                <ResultImage
                  url={image.thumbnail_url}
                  token={token}
                  alt={
                    image.metadata.title ?? `Ảnh ${image.image_id.slice(0, 8)}`
                  }
                />
                <div className="result-description">
                  <h3>
                    {image.metadata.title ??
                      `Ảnh ${image.image_id.slice(0, 8)}`}
                  </h3>
                  <p>{image.metadata.caption ?? "Chưa có chú thích"}</p>
                  <small>
                    {image.metadata.source_dataset} · {image.metadata.license}
                  </small>
                  {image.score !== null && (
                    <small>
                      {image.score_type} {image.score.toFixed(3)}
                    </small>
                  )}
                </div>
              </article>
            ))}
          </div>
          {response.error_code && (
            <p className="availability-note">
              Trạng thái: {response.error_code}
            </p>
          )}
        </>
      )}
    </section>
  );
}
