"""Agent measurements reuse Experiment/statistics; fixture scores are never real-world accuracy."""

import csv
from time import perf_counter

import httpx

from app.evaluation.rag import audit_citations
from app.evaluation.statistics import describe
from app.evaluation.tracking import Experiment


def evaluate_labeled_cases(rows, labels):
    fixture = labels.get("fixture") is True
    if not fixture and (labels.get("human_verified") is not True or not labels.get("annotator")):
        raise ValueError("VERIFIED_AGENT_LABELS_REQUIRED")
    expected = labels.get("cases", {})
    if set(expected) != {r["case_id"] for r in rows}:
        raise ValueError("LABEL_COVERAGE_MISMATCH")
    scores = {
        k: []
        for k in [
            "routing_accuracy",
            "tool_selection_accuracy",
            "entity_resolution_accuracy",
            "relationship_resolution_accuracy",
            "expected_image_identity_match",
            "workflow_success",
        ]
    }
    for row in rows:
        actual = row["result"]
        truth = expected[row["case_id"]]
        scores["routing_accuracy"].append(actual["search_mode"] == truth["search_mode"])
        scores["tool_selection_accuracy"].append(
            [s["tool"] for s in actual["steps"]] == truth["tools"]
        )
        scores["entity_resolution_accuracy"].append(
            {e["entity_id"] for e in actual["resolved_entities"]} == set(truth["entity_ids"])
        )
        scores["relationship_resolution_accuracy"].append(
            {e["evidence_id"] for e in actual["evidence"]} == set(truth["relationship_ids"])
        )
        scores["expected_image_identity_match"].append(
            {i["image_id"] for i in actual["results"]} == set(truth["image_ids"])
        )
        scores["workflow_success"].append(actual["status"] == truth["status"])
    return {
        "classification": "synthetic_fixture" if fixture else "human_verified_real_cases",
        "cases": len(rows),
        "metrics": {k: sum(v) / len(v) if v else None for k, v in scores.items()},
        "real_world_retrieval_accuracy": None
        if fixture
        else "requires separate relevance judgments",
    }


def run_agent_experiments(base_url, token, results, requests=16, include_llm=False):
    modes = ["A1", "A2", "A3", "A4"] if include_llm else ["A1", "A2", "A4"]
    experiment = Experiment(
        results, "agent", {"requests": requests, "modes": modes, "concurrency": 1, "seed": 42}
    )
    rows = []
    with httpx.Client(
        base_url=base_url, headers={"Authorization": "Bearer " + token}, timeout=45
    ) as client:
        status = client.get("/api/v1/search/agent/status")
        status.raise_for_status()
        runtime = client.get("/api/v1/system/search-runtime")
        runtime.raise_for_status()
        for number in range(requests):
            mode = modes[number % len(modes)]
            body = {"query": "a dog outdoors", "top_k": 3}
            if mode in {"A2", "A3"}:
                body["query"] = "Find landmarks in the city where Hoan Kiem Lake is located"
                body["planning_mode"] = "llm" if mode == "A3" else "deterministic"
            if mode == "A4":
                body["include_explanation"] = True
            started = perf_counter()
            row = {"case_id": f"{mode}_{number:03d}", "configuration": mode, "request": body}
            try:
                response = client.post(
                    "/api/v1/search" if mode == "A1" else "/api/v1/search/agent",
                    json={"text": body["query"], "mode": "text", "top_k": 3}
                    if mode == "A1"
                    else body,
                )
                row["http_status"] = response.status_code
                response.raise_for_status()
                value = response.json()
                row.update(
                    status="direct_search" if mode == "A1" else value["status"], result=value
                )
                if value.get("rag"):
                    row["citation_audit"] = audit_citations(value)
            except httpx.HTTPError as error:
                row.update(status="http_failed", error_type=type(error).__name__)
            row["client_ms"] = (perf_counter() - started) * 1000
            rows.append(row)
    groups = {}
    for mode in modes:
        cases = [r for r in rows if r["configuration"] == mode]
        generated = [
            r
            for r in cases
            if r.get("result", {}).get("rag", {}) and r["result"]["rag"]["generated"]
        ]
        tool_calls = sum(r.get("result", {}).get("tool_calls", 0) for r in cases)
        failed_tools = sum(
            s["status"] in {"failed", "timeout"}
            for r in cases
            for s in r.get("result", {}).get("steps", [])
        )
        timeouts = sum(
            r["status"] == "timeout"
            or r.get("result", {}).get("error_code") == "AGENT_DEADLINE_EXCEEDED"
            or any(s["status"] == "timeout" for s in r.get("result", {}).get("steps", []))
            for r in cases
        )
        groups[mode] = {
            "attempted": len(cases),
            "http_failures": sum(r["status"] == "http_failed" for r in cases),
            "failed_executions": sum(r["status"] == "failed" for r in cases),
            "partial_executions": sum(r["status"] == "partial" for r in cases),
            "validated_plans": sum(r.get("result", {}).get("plan_validated", False) for r in cases),
            "structural_query_success": sum(
                r.get("result", {}).get("query_success", False) for r in cases
            )
            if mode != "A1"
            else None,
            "insufficient_evidence": sum(r["status"] == "insufficient_evidence" for r in cases),
            "timeouts": timeouts,
            "timeout_rate": timeouts / len(cases),
            "generated": len(generated),
            "client_latency": describe([r["client_ms"] for r in cases]),
            "planning_latency": describe(
                [
                    r["result"]["latency"]["planning_ms"]
                    for r in cases
                    if mode != "A1" and "result" in r
                ]
            ),
            "tools_latency": describe(
                [
                    r["result"]["latency"]["tools_ms"]
                    for r in cases
                    if mode != "A1" and "result" in r
                ]
            ),
            "mean_hops": sum(r.get("result", {}).get("logical_hops", 0) for r in cases)
            / len(cases),
            "mean_tool_calls": tool_calls / len(cases),
            "tool_failure_rate": failed_tools / tool_calls if tool_calls else None,
            "provider_ttft": describe(
                [
                    r["result"]["latency"]["provider_ttft_ms"]
                    for r in generated
                    if r["result"]["latency"]["provider_ttft_ms"] is not None
                ]
            ),
            "request_ttlast": describe(
                [
                    r["result"]["latency"]["request_ttlast_ms"]
                    for r in generated
                    if r["result"]["latency"]["request_ttlast_ms"] is not None
                ]
            ),
            "real_world_quality": None,
        }
    value = {
        "status": "measured",
        "attempted": len(rows),
        "successful": sum(r["status"] != "http_failed" for r in rows),
        "failed": sum(r["status"] == "http_failed" for r in rows),
        "cases": rows,
        "agent_groups": groups,
        "runtime": runtime.json(),
        "agent_configuration": status.json(),
        "real_world_ground_truth": "not_available",
        "notes": [
            "A2/A3 real relationship KB is empty; correct abstention is not retrieval accuracy.",
            "A1/A4 share an image query; A2/A3 are a different relational task.",
            "Small-N timings are exploratory; provider/network load is uncontrolled.",
        ],
    }
    experiment.complete(value)
    return {
        "experiment_id": experiment.identifier,
        "directory": str(experiment.directory),
        "groups": groups,
    }


def report_agent_runs(runs, target):
    groups = []
    cases = []
    for run in runs:
        for name, group in run["result"].get("agent_groups", {}).items():
            groups.append(
                {
                    "experiment_id": run["experiment"]["experiment_id"],
                    "configuration": name,
                    **group,
                }
            )
        if "agent_groups" in run["result"]:
            cases.extend(
                {"experiment_id": run["experiment"]["experiment_id"], **row}
                for row in run["result"]["cases"]
            )
    if not groups:
        return []
    fields = [
        "experiment_id",
        "configuration",
        "attempted",
        "http_failures",
        "failed_executions",
        "partial_executions",
        "validated_plans",
        "insufficient_evidence",
        "timeouts",
        "timeout_rate",
        "generated",
        "mean_hops",
        "mean_tool_calls",
        "tool_failure_rate",
        "client_p90_ms",
        "client_p95_ms",
        "planning_p90_ms",
        "ttlast_p90_ms",
    ]
    with (target / "agent_summary.csv").open("x", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in groups:
            writer.writerow(
                {
                    **{k: row.get(k) for k in fields},
                    "client_p90_ms": row["client_latency"]["p90_ms"],
                    "client_p95_ms": row["client_latency"]["p95_ms"],
                    "planning_p90_ms": row["planning_latency"]["p90_ms"],
                    "ttlast_p90_ms": row["request_ttlast"]["p90_ms"],
                }
            )
    with (target / "agent_cases.csv").open("x", newline="") as handle:
        fields = [
            "experiment_id",
            "case_id",
            "configuration",
            "status",
            "http_status",
            "client_ms",
            "logical_hops",
            "tool_calls",
            "planner_attempts",
            "error_code",
        ]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in cases:
            writer.writerow({k: row.get(k, row.get("result", {}).get(k)) for k in fields})
    import matplotlib.pyplot as plt

    figure, axis = plt.subplots(figsize=(9, 5))
    axis.bar(
        [g["configuration"] + "\n" + g["experiment_id"][-6:] for g in groups],
        [g["client_latency"]["p90_ms"] for g in groups],
    )
    axis.set_ylabel("Client P90 ms, mọi lượt thử")
    axis.set_title("Thời gian Agent thăm dò; các nhóm có task khác nhau")
    figure.tight_layout()
    for extension in ["png", "svg"]:
        figure.savefig(target / ("agent_latency." + extension), dpi=160)
    plt.close(figure)
    lines = [
        "",
        "## Agent: thời gian thực thi và abstention, chưa có real-world quality labels",
        "",
        "| Nhóm / experiment | N / HTTP errors / insufficient | Client P90 ms | "
        "Plan P90 ms | Mean hops / calls |",
        "| --- | --- | --- | --- | --- |",
    ]
    for row in groups:
        plan = row["planning_latency"]["p90_ms"]
        lines.append(
            f"| {row['configuration']} / {row['experiment_id']} | "
            f"{row['attempted']} / {row['http_failures']} / "
            f"{row['insufficient_evidence']} | {row['client_latency']['p90_ms']:.2f} | "
            f"{plan if plan is not None else '—'} | "
            f"{row['mean_hops']:.2f} / {row['mean_tool_calls']:.2f} |"
        )
    lines.extend(
        [
            "",
            "A2/A3 chưa có quan hệ thật nên trả thiếu bằng chứng; không là multi-hop accuracy. "
            "A1/A4 dùng cùng image query, khác task với A2/A3. "
            "Xem agent_cases.csv và raw JSON để giữ mọi failure. "
            "Không có human quality bars khi thiếu nhãn.",
        ]
    )
    return lines
