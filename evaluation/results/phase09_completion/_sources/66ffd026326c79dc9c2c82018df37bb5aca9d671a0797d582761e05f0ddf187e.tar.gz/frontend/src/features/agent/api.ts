import type { ImageMetadata } from "../../types/api";

export interface AgentImage {
  image_id: string;
  rank: number;
  score: number | null;
  score_type: string | null;
  image_url: string;
  thumbnail_url: string;
  metadata: ImageMetadata;
}
export interface AgentResponse {
  query_id: string;
  status: string;
  query_success: boolean;
  dataset_status: string;
  results: AgentImage[];
  steps: {
    step_id: string;
    tool: string;
    status: string;
    duration_ms: number;
  }[];
  latency_ms: number;
  logical_hops: number;
  tool_calls: number;
  warnings: string[];
  error_code: string | null;
  relationship_summary: string | null;
  evidence?: { evidence_id: string; source_ref: string; verified: boolean }[];
  rag: {
    answer: string;
    error_code: string | null;
    citations: { image_id: string; quote: string }[];
  } | null;
}
function record(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
export function decodeAgent(value: unknown): AgentResponse {
  const invalid = () => {
    throw new Error("Phản hồi Agent không đúng định dạng.");
  };
  if (
    !record(value) ||
    typeof value.query_id !== "string" ||
    typeof value.status !== "string" ||
    typeof value.query_success !== "boolean" ||
    typeof value.dataset_status !== "string" ||
    typeof value.latency_ms !== "number" ||
    !Array.isArray(value.results) ||
    value.results.length > 50 ||
    !Array.isArray(value.steps) ||
    value.steps.length > 6 ||
    !Array.isArray(value.warnings) ||
    !value.warnings.every((w) => typeof w === "string")
  )
    return invalid();
  const ids = new Set<string>();
  if (
    value.evidence !== undefined &&
    (!Array.isArray(value.evidence) ||
      value.evidence.length > 100 ||
      !value.evidence.every(
        (e) =>
          record(e) &&
          typeof e.evidence_id === "string" &&
          typeof e.source_ref === "string" &&
          typeof e.verified === "boolean",
      ))
  )
    return invalid();
  for (const image of value.results) {
    if (
      !record(image) ||
      typeof image.image_id !== "string" ||
      !/^[a-f0-9-]{36}$/.test(image.image_id) ||
      ids.has(image.image_id) ||
      !record(image.metadata) ||
      !Array.isArray(image.metadata.tags) ||
      !(
        image.score === null ||
        (typeof image.score === "number" && Number.isFinite(image.score))
      ) ||
      image.image_url !==
        `/api/v1/images/${image.image_id}/content?variant=original` ||
      image.thumbnail_url !==
        `/api/v1/images/${image.image_id}/content?variant=thumbnail`
    )
      return invalid();
    ids.add(image.image_id);
  }
  if (
    !value.steps.every(
      (s) =>
        record(s) &&
        typeof s.step_id === "string" &&
        typeof s.tool === "string" &&
        typeof s.status === "string" &&
        typeof s.duration_ms === "number",
    )
  )
    return invalid();
  if (
    value.rag !== null &&
    (!record(value.rag) ||
      typeof value.rag.answer !== "string" ||
      !Array.isArray(value.rag.citations) ||
      !value.rag.citations.every(
        (c) =>
          record(c) &&
          typeof c.image_id === "string" &&
          ids.has(c.image_id) &&
          typeof c.quote === "string",
      ))
  )
    return invalid();
  return value as unknown as AgentResponse;
}

export async function searchAgent(
  body: object,
  token: string,
  signal: AbortSignal,
  onProgress: (event: string, data: Record<string, unknown>) => void,
): Promise<AgentResponse> {
  const controller = new AbortController();
  const abort = () => controller.abort();
  signal.addEventListener("abort", abort, { once: true });
  if (signal.aborted) controller.abort();
  const timer = setTimeout(abort, 65_000);
  let reader: ReadableStreamDefaultReader<Uint8Array> | undefined;
  try {
    const base = import.meta.env.VITE_API_BASE_URL ?? "/api/v1";
    const response = await fetch(
      `${base.replace(/\/$/, "")}/search/agent/stream`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "text/event-stream",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(body),
        signal: controller.signal,
      },
    );
    if (!response.ok) {
      const payload: unknown = await response.json();
      throw new Error(
        record(payload) &&
          record(payload.error) &&
          typeof payload.error.message === "string"
          ? payload.error.message
          : "Agent chưa thể xử lý yêu cầu.",
      );
    }
    if (
      !response.body ||
      !response.headers.get("content-type")?.startsWith("text/event-stream")
    )
      throw new Error("Agent không trả luồng tiến độ hợp lệ.");
    reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "",
      received = 0;
    while (true) {
      const chunk = await reader.read();
      if (chunk.done) break;
      received += chunk.value.byteLength;
      if (received > 2 * 1024 * 1024)
        throw new Error("Phản hồi Agent vượt giới hạn.");
      buffer = (buffer + decoder.decode(chunk.value, { stream: true })).replace(
        /\r\n/g,
        "\n",
      );
      let boundary;
      while ((boundary = buffer.indexOf("\n\n")) >= 0) {
        const block = buffer.slice(0, boundary);
        buffer = buffer.slice(boundary + 2);
        const event = block
          .split("\n")
          .find((l) => l.startsWith("event:"))
          ?.slice(6)
          .trim();
        const raw = block
          .split("\n")
          .filter((l) => l.startsWith("data:"))
          .map((l) => l.slice(5).trimStart())
          .join("\n");
        if (!event || !raw) continue;
        const data: unknown = JSON.parse(raw);
        if (event === "agent_completed" || event === "agent_partial")
          return decodeAgent(data);
        if (!record(data)) throw new Error("Tiến độ Agent không hợp lệ.");
        if (event === "error" && data.retrieval_preserved === true) continue;
        if (event === "error")
          throw new Error(
            `Agent dừng: ${typeof data.code === "string" ? data.code : "AGENT_FAILED"}`,
          );
        if (
          [
            "planning_started",
            "planning_completed",
            "tool_started",
            "tool_completed",
            "retrieval_completed",
            "generation_started",
          ].includes(event)
        )
          onProgress(event, data);
      }
    }
    throw new Error("Luồng Agent kết thúc khi chưa có kết quả xác nhận.");
  } catch (error) {
    if (signal.aborted)
      throw new Error("Đã hủy yêu cầu Agent.", { cause: error });
    if (controller.signal.aborted)
      throw new Error("Agent đã hết thời gian chờ.", { cause: error });
    throw error;
  } finally {
    clearTimeout(timer);
    signal.removeEventListener("abort", abort);
    await reader?.cancel().catch(() => undefined);
    reader?.releaseLock();
  }
}
